//
//  ABC.h
//  ABC
//
//  Created by hyperlink on 07/11/20.
//  Copyright © 2020 xyz. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ABC.
FOUNDATION_EXPORT double ABCVersionNumber;

//! Project version string for ABC.
FOUNDATION_EXPORT const unsigned char ABCVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ABC/PublicHeader.h>


