//
//  SDKONE.h
//  SDKONE
//
//  Created by hyperlink on 06/11/20.
//

#import <Foundation/Foundation.h>

//! Project version number for SDKONE.
FOUNDATION_EXPORT double SDKONEVersionNumber;

//! Project version string for SDKONE.
FOUNDATION_EXPORT const unsigned char SDKONEVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SDKONE/PublicHeader.h>


